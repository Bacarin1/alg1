#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct ocorrencia {
	char *palavra;
	short int qtdLetras;
	short int qtd;
} ocorrencia;

ocorrencia criarOcorrencia(char *buffer, short int qtdLetras);
int verificarExistente(char *buffer, ocorrencia *palavras, short int qtdPalavras);
void ordenar(ocorrencia *palavras, short int qtdPalavras);
void limparOcorrencias(ocorrencia *palavras, short int *qtdPalavras);