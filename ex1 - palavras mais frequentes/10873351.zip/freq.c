#include"freq.h"

ocorrencia criarOcorrencia(char *buffer, short int qtdLetras) {
	ocorrencia o;
	o.palavra = malloc((qtdLetras + 1) * sizeof(char));
	strcpy(o.palavra, buffer);
	o.qtdLetras = qtdLetras;
	o.qtd = 1;

	return o;
}

int verificarExistente(char *buffer, ocorrencia *palavras, short int qtdPalavras) {

	for(int i = 0; i < qtdPalavras; i++) {
		if(strcmp(buffer, palavras[i].palavra) == 0)
			return i;
	}

	return -1;
}

void ordenar(ocorrencia *palavras, short int qtdPalavras) {
	int i, j;
	ocorrencia aux;

	for(i = 1; i < qtdPalavras; i++) {
		for(j = 0; j < qtdPalavras - 1; j++) {
			if(palavras[j].qtd < palavras[j+1].qtd) {
				aux = palavras[j];
				palavras[j] = palavras[j+1];
				palavras[j+1] = aux;
			}
			else if(palavras[j].qtd == palavras[j+1].qtd) {
				if(strcmp(palavras[j].palavra, palavras[j + 1].palavra) > 0) { //palavras[j] > palavras[j+1]
					aux = palavras[j];
					palavras[j] = palavras[j+1];
					palavras[j + 1] = aux;
				}
			}
		}
	}
}

void limparOcorrencias(ocorrencia *palavras, short int *qtdPalavras) {
	for(int i = 0; i < *qtdPalavras; i++) {
		free(palavras[i].palavra);
		palavras[i].qtdLetras = 0;
		palavras[i].qtd = 0;
	}
	*qtdPalavras = 0;
	free(palavras);
}