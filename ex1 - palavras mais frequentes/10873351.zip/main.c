/*
* Nome: Gabriel Bacarin #10873351
* Exercício 1 - Palavras Mais Frequentes
*/
#include"freq.h"


int main() {
	char entrada;
	int precisaBarraN = 0;
	
	do {
		char *buffer = malloc(0 * sizeof(char));
		short int qtdLetras = 0;

		ocorrencia *palavras = malloc(0 * sizeof(ocorrencia));
		short int qtdPalavras = 0;

		do {
			entrada = fgetc(stdin);
			if(entrada == EOF) {
				limparOcorrencias(palavras, &qtdPalavras);
				free(buffer);
				exit(0);
			}
			if(entrada == '\r') {
				continue;
			}

			if(precisaBarraN == 1) {
				printf("\n");
				precisaBarraN = 0;
			}

			if(entrada != ' ' && entrada != '\n') { //a entrada ainda faz parte da mesma palavra
				qtdLetras++;
				buffer = realloc(buffer, qtdLetras * sizeof(char));
				buffer[qtdLetras - 1] = entrada;
			}
			else { //a palavra acabou
				//verificar se a palavra do buffer já existe em *palavras
				buffer = realloc(buffer, (qtdLetras + 1) * sizeof(char));
				buffer[qtdLetras] = '\0';
				
				int indice = verificarExistente(buffer, palavras, qtdPalavras);

				if(indice != -1) { //palavra já existe
					palavras[indice].qtd = palavras[indice].qtd + 1;
					
				}
				else { //palavra ainda não existe
					qtdPalavras++;
					palavras = realloc(palavras, qtdPalavras*sizeof(ocorrencia));
					palavras[qtdPalavras - 1] = criarOcorrencia(buffer, qtdLetras);
				}
				buffer = realloc(buffer, 0*sizeof(char));
				qtdLetras = 0;
			}

		} while(entrada != '\n');

		ordenar(palavras, qtdPalavras);

		int qtdMostrar;
		scanf("%d ", &qtdMostrar);

		for(int i = 0; i < qtdMostrar; i++) {
			printf("%s %d\n", palavras[i].palavra, palavras[i].qtd);
			if(i == qtdPalavras - 1)
				break;
		}

		limparOcorrencias(palavras, &qtdPalavras);
		free(buffer);
		precisaBarraN = 1;

	} while(entrada != EOF);

	return 0;
}