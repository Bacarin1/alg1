#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "lista.h"

typedef struct no no_t;

struct no {
	elem info;
	no_t *prox;
};

struct lista {
	no_t *ini, *fim;
	int tam;
};

lista_t *cria() {
	lista_t *l;
	l = malloc(sizeof(lista_t));
	assert(l != NULL);

	l->ini = NULL;
	l->fim = NULL;
	l->tam = 0;

	return l;
}

void liberar(lista_t *l) {
	if(l != NULL) {
		no_t *p = l->ini;
		
		while(p != NULL) {
			l->ini = p->prox;
			free(p);
			p = l->ini;
		}
		
		free(l);
	}
}

void insere(lista_t *l, elem x) {
	assert(l != NULL);

	no_t *p = malloc(sizeof(no_t));
	p->info = x;
	p->prox = NULL;

	// 1o. caso: lista vazia
	if(l->ini == NULL) {
		l->ini = p;
	} else { // 2o. caso: lista com pelo menos um elemento
		l->fim->prox = p;
	}
	l->fim = p;

	l->tam++;
}

int tamanho(lista_t *l) {
	assert(l != NULL);
	return l->tam;
}

void imprimir(lista_t *l) {
	assert(l != NULL);

	no_t *p = l->ini;
	int count = 0;

	while(p != NULL) {
		printf("%d", p->info);
		p = p->prox;
		count++;
		if(count != l->tam) {
			printf(" ");
		}
	}
}

void rotacionar(lista_t *l) {
	assert(l != NULL);

	no_t *temp;
	temp = l->ini;

	l->ini = l->fim;
	l->ini->prox = temp;

	l->fim = temp;
	for(int i = 1; i < (l->tam - 1); i++) {
		l->fim = l->fim->prox;
	}

	l->fim->prox = NULL;
}