#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main() {
	
	int qtdListas;
	scanf("%d ", &qtdListas);

	for(int i = 0; i < qtdListas; i++) {
		int qtdElementos, rot;

		scanf("%d %d ", &qtdElementos, &rot);

		lista_t *l = cria();

		for(int j = 0; j < qtdElementos; j++) {
			int adicionar;
			scanf("%d", &adicionar);
			fgetc(stdin);
			insere(l, adicionar);
		}

		for(int j = 0; j < rot; j++) {
			rotacionar(l);
		}

		imprimir(l);

		if(i != qtdListas - 1) {
			printf("\n");
		}

		liberar(l);

	}

	

	

	return 0;
}
