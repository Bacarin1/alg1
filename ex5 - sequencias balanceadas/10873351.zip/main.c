#include<stdio.h>
#include<stdlib.h>
#include"pilha.h"

int main() {
	
	char input;
	int numAspas;
	int balanceado;

	do {
		pilha_t *pilha = create();
		balanceado = 1;
		numAspas = 0;

		do {
			input = fgetc(stdin);

			if(input == ' ')
				continue;
			
			if(input == EOF)
				break;

			if(input == '\r')
				continue;

			if(input == '"') {
				numAspas++;
				continue;
			}

			if(input == '(' || input == '[' || input == '{') {
				push(pilha, input);
			}

			if(input == ')' || input == ']' || input == '}') {				
				if(isEmpty(pilha) == 0) {
					elem popped;
					pop(pilha, &popped);

					if(input == ')') {
						if(popped != '(')
							balanceado = 0;
						continue;
					}
					if(input == ']') {
						if(popped != '[')
							balanceado = 0;
						continue;
					}
					if(input == '}') {
						if(popped != '{')
							balanceado = 0;
						continue;
					}
				}
				else {
					balanceado = 0;
				}
			}

		} while(input != '\n');

		if((numAspas % 2) != 0) {
			balanceado = 0;
		}

		if(balanceado == 1) {
			printf("BALANCEADO\n");
		}
		else {
			printf("NÃO BALANCEADO\n");
		}

		destroy(pilha);

	} while(input != EOF);

	return 0;
}