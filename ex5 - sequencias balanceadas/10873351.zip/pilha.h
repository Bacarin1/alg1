//essas coisas são visíveis para o usuário que vai usar essa TAD
#define tamPilha 400

typedef char elem;
typedef struct pilha pilha_t;

pilha_t *create();
void destroy(pilha_t *p);
int isFull(pilha_t *p);
int isEmpty(pilha_t *p);
int push(pilha_t *p, elem x);
int pop(pilha_t *p, elem *x);
int top(pilha_t *p, elem *x);
