//lista.c
#include<stdio.h>
#include<stdlib.h>
#include"lista.h"

typedef struct no no_t;

struct no {
	elem info;
	no_t *ant, *prox;
};

struct lista {
	no_t *inicio, *fim;
};

lista_t *criar() {
	lista_t *p;
	p = malloc(sizeof(lista_t));
	p->inicio = NULL;
	p->fim = NULL;

	return p;
}

void liberar(lista_t *l) {
	if(l != NULL) {
		no_t *aux = l->inicio;
		while(aux != NULL) {
			l->inicio = l->inicio->prox;
			free(aux);
			aux = l->inicio;
		}
		free(l);
	}
}

int inserir(lista_t *l, elem x) {
	if(l == NULL) {
		return -1;
	}

	no_t *p = malloc(sizeof(no_t));
	p->info = x;
	p->prox = NULL;
	p->ant = NULL;

	no_t *aux, *ant;
	ant = NULL;
	aux = l->inicio;

	while(aux != NULL && x.index > aux->info.index) {
		ant = aux;
		aux = aux->prox;
	}

	if(aux != NULL && x.index == aux->info.index) { // indice já existe
		free(p);
		return 0;
	}

	if(ant == NULL) { //insere no inicio
		p->prox = l->inicio;
		if(l->inicio != NULL)
			l->inicio->ant = p;
		l->inicio = p;
	}
	else {
		p->prox = ant->prox;
		ant->prox = p;
		if(p->prox != NULL) {
			p->prox->ant = p;
		}
		else {
			l->fim = p;
		}
		p->ant = ant;
	}
	return 1;
}

int remover(lista_t *l, int index) {
	if(l == NULL)
		return -1;

	no_t *p = l->inicio;
	no_t *ant = NULL;

	while(p != NULL && index != p->info.index) {
		ant = p;
		p = p->prox;
	}

	if(p == NULL) {
		return 0;
	}

	if(ant == NULL) {
		l->inicio = l->inicio->prox;
		if(l->inicio != NULL) l->inicio->ant = NULL;
		else l->fim = NULL;
		free(p);
	}
	else {
		if(p->prox == NULL) {
			l->fim = p->ant;
			ant->prox = NULL;
			free(p);
		}
		else {
			ant->prox = p->prox;
			p->prox->ant = ant;
			free(p);
		}
	}
	return 1;
}

void imprimir(lista_t *l) {


	no_t *p = l->inicio;

	if(l->inicio == NULL) {
		printf("VAZIA\n");
		return;
	}

	while(p != NULL) {
		printf("%d, %s;", p->info.index, p->info.name);
		p = p->prox;
		if(p != NULL)
			printf(" ");
	}
	printf("\n");
}
