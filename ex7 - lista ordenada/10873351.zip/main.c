/*
	Nome: Gabriel Bacarin #10873351
	ALG1 - Exercício 7
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lista.h"

int main() {
	lista_t *db = criar();
	elem info;
	int rem;
	char prox;

	char comando[10];

	while(1) {
		scanf("%s", comando);
		//printf("%s\n", comando);
		prox = fgetc(stdin);

		//printf("%c\n", prox);

		if(prox == EOF) {
			break;
		}

		if(strcmp(comando, "INSERE") == 0) { //vai inserir uma entrada
			scanf("%d ", &info.index);
			char entrada;
			int pos = 0;
			while(1) {
				entrada = fgetc(stdin);
				if(entrada == '\n') {
					info.name[pos] = '\0';
					break;
				}
				else {
					if(entrada != '\r') {
						info.name[pos] = entrada;
						pos++;
					}
				}
			}
			int retorno;
			retorno = inserir(db, info);
			if(retorno == 0) {
				printf("INVALIDO\n");
			}	
		}

		if(strcmp(comando, "REMOVE") == 0) { //vai remover o índice informado
			scanf("%d ", &rem);
			int retorno;
			retorno = remover(db, rem);
			if(retorno != 1) {
				printf("INVALIDO\n");
			}
		}

		if(strcmp(comando, "IMPRIMIR") == 0) { //vai imprimir
			imprimir(db);
		}

		strcpy(comando, "");
	}

	liberar(db);

	return 0;
}