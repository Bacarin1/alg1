#define MAXLEVEL 40 // nível máximo da skiplist
#define P 0.5 // chance de criação de novo nível do node

typedef struct node no_t;
typedef struct skipList skip;

no_t *criarNode(int level, char *nome, char *descricao);
skip *criarSkip();
int inserirNode(skip *sl, char *nome, char *descricao);
void imprimirLista(skip *sl);
void desalocarLista(skip *sl);
int excluirNode(skip *sl, char *nomeExc);
int alterarNode(skip *sl, char *nome, char *descricao);
int procurarNode(skip *sl, char *nome);
void imprimirCaractere(skip *sl, char caractere);