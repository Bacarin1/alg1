#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"skip.h"

typedef struct node no_t;

struct node {
	char nome[51];
	char descricao[141];

	int level;
	no_t **prox;
};

struct skipList {
	no_t *header;
	int level; //nivel da skiplist
};

// gerador de números aleatórios entre 0 e 1
float randomFloat() {
	float random;					//valor máximo que pode ser gerado por rand()
	random = (float)rand() / (float)(RAND_MAX);
	return random;
}

// gera um nível entre 1 e MAXLEVEL, com probabilidade P de gerar o novo nível
int randomLevel() {
	int level = 1;
	while(randomFloat() < P && level < MAXLEVEL)
		level++;

	return level;
}
//cria um novo node para a lista e retorna ele pronto
no_t *criarNode(int level, char *nome, char *descricao) {
	no_t *novoNo = malloc(sizeof(no_t));
	novoNo->level = level;
	novoNo->prox = malloc((level + 1) * sizeof(no_t*));

	for(int i = 0; i < (level + 1); i++) {
		novoNo->prox[i] = NULL;
	}

	strcpy(novoNo->nome, nome);
	strcpy(novoNo->descricao, descricao);

	return novoNo;
}
//cria uma skiplist, com seu header pronto até o nível máximo
skip *criarSkip() {
	skip *sl = malloc(sizeof(skip));

	char null[] = "\0";

	sl->header = criarNode(MAXLEVEL, null, null);
	sl->level = 0;

	return sl;
}

// cria um novo node
int inserirNode(skip *sl, char *nome, char *descricao) {
	no_t **novoNo = malloc((MAXLEVEL + 1) * sizeof(no_t *)); 
	// o novoNo acumula todos os nós que terão seus ->prox[i] alterados para comportar o novo nó

	no_t *x = sl->header;
	int lvl = sl->level;

	for(int i = lvl; i >= 0; i--) { //procurando onde inserir o nó
		while(x->prox[i] != NULL && strcmp(x->prox[i]->nome, nome) < 0) {
			x = x->prox[i];
		}
		novoNo[i] = x;
	}

	x = x->prox[0];

	//caso a palavra ainda não exista, vai inserir ela
	if(x == NULL || strcmp(x->nome, nome) != 0) {
		int novoLvl = randomLevel();
		// nivel do nó é maior que o nível da skiplist
		if(novoLvl > lvl) {
			for(int i = lvl + 1; i <= novoLvl; i++) {
				novoNo[i] = sl->header; //novos níveis começam no header
			}
			sl->level = novoLvl;
			//printf("level da skip %d\n", sl->level);
		}
	
		//x vai receber as informações que serão inseridas
		x = criarNode(novoLvl, nome, descricao);

		//vai inserir na skiplist
		for(int i = 0; i <= novoLvl; i++) {
			x->prox[i] = novoNo[i]->prox[i];
			novoNo[i]->prox[i] = x;
		}
		//atualizando os níveis superiores do header
		if(novoLvl > lvl) {
			for(int i = lvl + 1; i <= novoLvl; i++) {
				sl->header->prox[i] = x;
			}
		}
		//printf("adicionando %s no nivel %d\n", nome, novoLvl);
		
		free(novoNo);
		return 0;
	}
	free(novoNo);
	return -1;
}

void imprimirNode(no_t *node) {
	//essa função substitui o printf porque ele não estava funcionando direito
	//printf("%s %s\n", node->nome, node->descricao);
	char nome[51];
	char desc[141];
	int in = 0, id = 0;

	//putchar('\n');

	strcpy(nome, node->nome);
	strcpy(desc, node->descricao);

	char put;
	while(1) {
		put = nome[in];
		if(put == '\0') {
			putchar(' ');
			break;
		}
		putchar(put);
		in++;
	}

	while(1) {
		put = desc[id];
		if(put == '\0') {
			break;
		}
		putchar(put);
		id++;
	}

	putchar('\n');
}

//função extra que imprime a skiplist inteira
void imprimirLista(skip *sl) {
	no_t *x = sl->header;

	while(x != NULL) {
		if(strcmp(x->nome, "") != 0) {
			printf("Verbete: %s\n%s\n", x->nome, x->descricao);
		}		
		x = x->prox[0];
	}	
}

void desalocarLista(skip *sl) {
	if(sl == NULL)
		return;

	no_t *x = sl->header;

	while(x != NULL) {
		sl->header = sl->header->prox[0];
		free(x);
		x = sl->header;
	}
	free(sl);
}

int excluirNode(skip *sl, char *nomeExc) {
	no_t *prev = NULL;
	no_t *x = sl->header;
	no_t *next = NULL;
	no_t *delete = NULL;
	int lvl = sl->level;

	for(int i = lvl; i >= 0; i--) {
		while(x->prox[i] != NULL && strcmp(x->prox[i]->nome, nomeExc) < 0) {
			prev = x;
			x = x->prox[i];
			//printf("x atual da passada %s, level %d\n", x->nome, i);
		}
		if(x->prox[i] != NULL) {
			if(strcmp(x->prox[i]->nome, nomeExc) == 0) { //o próximo é o que vai ser removido, então o atual vai se ligar
				//novoNo[i] = x;						 //no outro no mesmo nível
				prev = x;
				x = x->prox[i];
				next = x->prox[i];

				prev->prox[i] = next; // ligando o anterior ao próximo, pulando o que será removido

				if(prev == sl->header && next == NULL) { // isso acontece quando o nó removido é o último do seu nível,
					sl->level = sl->level - 1;			 // então o nível da skiplist decrementa
				}

				delete = x;
				x = prev; // retornando para a posição de análise
			}
		}
	}
	//liberando o nó ou retornando negativo
	if(delete != NULL && strcmp(delete->nome, nomeExc) == 0) {
		free(delete);
		return 0;
	}
	else
		return -1;
}

// procura o node da forma que já estava sendo feita e altera a descrição se encontrar ele
int alterarNode(skip *sl, char *nome, char *descricao) {
	no_t *x = sl->header;
	int lvl = sl->level;

	for(int i = lvl; i >= 0; i--) {
		while(x->prox[i] != NULL && strcmp(x->prox[i]->nome, nome) < 0) {
			x = x->prox[i];
		}
	}

	x = x->prox[0];

	if(x == NULL)
		return -1;

	if(strcmp(x->nome, nome) == 0) {
		strcpy(x->descricao, descricao);
		return 0;
	}
	return -1;
}

//procura node pelo nome, e se achar imprime ele
int procurarNode(skip *sl, char *nome) {
	no_t *x = sl->header;
	int lvl = sl->level;

	//vai do maior para o menor nível
	for(int i = lvl; i >= 0; i--) {
		//caso o proximo exista e seja menor que o buscado
		while(x->prox[i] != NULL && strcmp(x->prox[i]->nome, nome) < 0) {
			x = x->prox[i];
		}
	}
	if(x == NULL)
		return -1;
	//o próximo no nível 0
	x = x->prox[0];

	if(x == NULL)
		return -1;
	if(strcmp(x->nome, nome) != 0)
		return -1;
	else
		imprimirNode(x);
	return 0;
}

//imprime todos os nodes iniciados pelo caractere fornecido
void imprimirCaractere(skip *sl, char caractere) {
	no_t *x = sl->header;
	int lvl = sl->level;

	//vai do maior para o menor nível
	for(int i = lvl; i >= 0; i--) {
		//caso o proximo exista e seja menor que o buscado
		while(x->prox[i] != NULL && (x->prox[i]->nome[0] < caractere)) {
			x = x->prox[i];
		}
	}

	if(x == NULL) {
		printf("NAO HA PALAVRAS INICIADAS POR %c\n", caractere);
		return;
	}

	x = x->prox[0];

	if(x->nome[0] != caractere) {
		printf("NAO HA PALAVRAS INICIADAS POR %c\n", caractere);
		return;
	}
	while(1) {
		imprimirNode(x);
		x = x->prox[0];
		if(x == NULL || x->nome[0] != caractere)
			break;
	}
}