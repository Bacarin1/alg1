/*
	Nome: Gabriel Bacarin #10873351
	Projeto 1 - Skip lists
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"skip.h"

int lerComando(char *comando) {
	char entrada;
	int pos = 0;
	while(1) {
		entrada = fgetc(stdin);
		if(entrada == EOF)
			return -1;
		if(entrada == ' ' || entrada == '\n') {
			comando[pos] = '\0';
			break;
		}
		else {
			if(entrada != '\r') {
				comando[pos] = entrada;
				pos++;
			}
		}
	}
	return 0;
}

void lerNome(char *nome) {
	char entrada;
	int pos = 0;
	while(1) {
		entrada = fgetc(stdin);
		if(entrada == ' ' || entrada == '\n' || entrada == EOF) {
			nome[pos] = '\0';
			break;
		}
		else {
			if(entrada != '\r') {
				nome[pos] = entrada;
				pos++;
			}
		}
	}
}

void lerDesc(char *desc) {
	char entrada;
	int pos = 0;
	while(1) {
		entrada = fgetc(stdin);
		if(entrada == '\n' || entrada == EOF) {
			desc[pos] = '\0';
			break;
		}
		else {
			if(entrada != '\r') {
				desc[pos] = entrada;
				pos++;
			}
		}
	}
}

void limparStrings(char *nome, char *desc, char *comando) {
	strcpy(nome, "\0");
	strcpy(desc, "\0");
	strcpy(comando, "\0");
}

int main() {
	srand(2);
	skip *sl = criarSkip();

	char nome[51];
	char desc[141];
	char comando[11];
	int pr = 0;

	while(1) {
		pr = lerComando(comando);
		if(pr == -1)
			break;

		if(strcmp(comando, "insercao") == 0) {
			//printf("INSERE\n");
			int retorno;
			lerNome(nome);
			lerDesc(desc);
			retorno = inserirNode(sl, nome, desc);
			if(retorno != 0) {
				printf("OPERACAO INVALIDA\n");
			}
			limparStrings(nome, desc, comando);
		}
		if(strcmp(comando, "remocao") == 0) {
			//printf("REMOVE\n");			
			int retorno;
			lerNome(nome);
			retorno = excluirNode(sl, nome);
			if(retorno != 0){
				printf("OPERACAO INVALIDA\n");
			}
			limparStrings(nome, desc, comando);
		}
		if(strcmp(comando, "busca") == 0) {
			//printf("BUSCA\n");	
			int retorno;
			lerNome(nome);
			retorno = procurarNode(sl, nome);
			if(retorno != 0) {
				printf("OPERACAO INVALIDA\n");
			}
			limparStrings(nome, desc, comando);
		}
		if(strcmp(comando, "alteracao") == 0) {
			//printf("ALTERA\n");		
			int retorno;
			lerNome(nome);
			lerDesc(desc);
			retorno = alterarNode(sl, nome, desc);
			if(retorno != 0) {
				printf("OPERACAO INVALIDA\n");
			}
			limparStrings(nome, desc, comando);
		}
		if(strcmp(comando, "impressao") == 0) {
			//printf("IMPRIME\n");	
			char caractere = fgetc(stdin);
			fgetc(stdin);
			fgetc(stdin);
			imprimirCaractere(sl, caractere);
			limparStrings(nome, desc, comando);
		}
	}

	//imprimirLista(sl);
	desalocarLista(sl);

	return 0;
}