typedef int elem;

typedef struct no no_t;

typedef struct arvore {
	no_t *raiz;
} arvore_t;

typedef struct node {
	int id;
	int valor;
	int idEsq, idDir;
} nodes;

arvore_t *criar();
int esta_vazia(arvore_t *a);
void finalizar(no_t *raiz);
void imprimir(no_t *raiz);
int altura(no_t *raiz);
no_t *busca(no_t *raiz, int id);
no_t *busca_pai(no_t *raiz, elem x);
int inserir_esq(arvore_t *a, int id, elem x, elem idPai);
int inserir_dir(arvore_t *a, int id, elem x, elem idPai);
int remover(arvore_t *a, elem x);
void pre_ordem(no_t *raiz);
void em_ordem(no_t *raiz);
void pos_ordem(no_t *raiz);
void inserirRaiz(arvore_t *arvore, int id, elem x);
void inserirNodes(arvore_t *arvore, nodes *nos, int id, int idPai);
void verificarSoma(no_t *raiz, int *isSoma);