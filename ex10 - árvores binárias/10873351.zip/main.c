/*
	nome: Gabriel Bacarin #10873351
*/
#include<stdio.h>
#include<stdlib.h>
#include"ab.h"


int main() {

	int qtdNos;
	scanf("%d ", &qtdNos);

	nodes *nos = malloc(qtdNos * sizeof(nodes));

	arvore_t *arvore = criar();

	for(int i = 0; i < qtdNos; i++) {
		scanf(" %d %d %d %d ", &nos[i].id, &nos[i].valor, &nos[i].idEsq, &nos[i].idDir);
	}

	int zero = 0;
	inserirRaiz(arvore, nos[0].id, nos[0].valor);
	inserirNodes(arvore, nos, 0, -1);
	int isSoma = 1;
	verificarSoma(arvore->raiz, &isSoma);
	if(isSoma == 1)	{
		printf("VERDADEIRO\n");
	}
	else {
		printf("FALSO\n");
	}
	
	finalizar(arvore->raiz);
	free(arvore);
	free(nos);
	//imprimir(arvore->raiz);

	return 0;
}