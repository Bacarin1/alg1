#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

typedef struct no no_t;

struct no {
	elem info;
	no_t *prox;
};

typedef struct lista {
	no_t *ini, *fim;
} lista_t;

lista_t *cria() {
	lista_t *l;
	l = (lista_t *)malloc(sizeof(lista_t));

	l->ini = NULL;
	l->fim = NULL;

	return l;
}

void liberar(lista_t *l) {
	no_t *p = l->ini;
	while(p != NULL) {
		l->ini = p->prox;
		free(p);
		p = l->ini;
	}
	free(l);
}

void insere(lista_t *l, elem x) {

	no_t *p = (no_t *)malloc(sizeof(no_t));
	p->info = x;
	p->prox = NULL;

	// 1o. caso: lista vazia
	if(l->ini == NULL) {
		l->ini = p;
	} else { // 2o. caso: lista com pelo menos um elemento
		l->fim->prox = p;
	}
	l->fim = p;
}

int procuraGrau(lista_t *l, int grau) {
	no_t *p = l->ini;

	if(grau == 0 && p != NULL)
		return 1;
	if(grau == 0 && p == NULL)
		return -1;

	for(int i = 0; i < grau; i++) {
		p = p->prox;
		if(p == NULL) {
			return -1;
		}
	}

	return 1;
}

void somaCoef(lista_t *pol, int coeficiente, int grau) {
	no_t *p = pol->ini;

	for(int i = 0; i < grau; i++) {
		p = p->prox;
		if(p == NULL) {
			printf("DEU RUIM\n");
		}
	}

	p->info = p->info + coeficiente;
}

void imprimir(lista_t *l, int grau) {
	no_t *p = l->ini;
	
	printf("(");
	int i = -1;

	while(p != NULL) {
		printf("%d", p->info);
		i++;
		if(i != grau)
			printf(",");
		p = p->prox;
	}

	printf(")\n");
}
