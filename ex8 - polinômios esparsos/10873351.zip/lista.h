typedef int elem;
typedef struct lista lista_t;

lista_t *cria();
void liberar(lista_t *l);
void insere(lista_t *l, elem x);
void imprimir(lista_t *l, int grau);

int procuraGrau(lista_t *l, int grau);
void somaCoef(lista_t *pol, int coeficiente, int grau);
