/*
	Nome: Gabriel Bacarin #10873351
	ALG1 - Exercício 8
*/
#include<stdio.h>
#include<stdlib.h>
#include"lista.h"


int main() {
	int qtdTestes;
	scanf("%d ", &qtdTestes);
	lista_t *pol;

	for(int i = 0; i < qtdTestes; i++) {
		int qtdPol;
		scanf("%d ", &qtdPol);

		pol = cria();
		int hiDeg = -1;
		char entrada;

		for(int j = 0; j < qtdPol; j++) {
			
			char buffer[13];
			int indexBuffer = 0, coeficiente, grauPol = -1;

			while(1) {
				entrada = fgetc(stdin);
				if(entrada == '\n' || entrada == EOF) { //se a entrada é o fim da linha
					break;
				}
				if(entrada == '\r' || entrada == '(') {
					continue;
				}
				//se a entrada é um número
				if(entrada != '(' && entrada != ')' && entrada != ',' && entrada != ' ') {
					buffer[indexBuffer] = entrada;
					indexBuffer++;
				}
				if(entrada == ',' || entrada == ')') { //se a entrada é o fim de um polinômio
					buffer[indexBuffer] = '\0';
					coeficiente = atoi(buffer);
					grauPol++;
					indexBuffer = 0;

					if(procuraGrau(pol, grauPol) == -1) { // caso o coeficiente de tal grau
						insere(pol, coeficiente);		  // ainda não exista
					}
					else { // caso o coeficiente já exista
						somaCoef(pol, coeficiente, grauPol);
					}
				}
				if(grauPol > hiDeg) { //atualiza o grau do maior polinômio
					hiDeg = grauPol;
				}
			}
		}
		// depois de processar todos os polinômios
		imprimir(pol, hiDeg);

		liberar(pol);
		if(entrada == EOF)
			exit(0);

	} //fim do caso de teste

	return 0;
}