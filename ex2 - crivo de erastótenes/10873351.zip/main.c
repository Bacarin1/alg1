#include<stdio.h>
#include<stdlib.h>
#include"primos.h"

int main() {
	
	int *primos = gerarPrimos();

	int qtdImpressoes;
	scanf("%d", &qtdImpressoes);

	int *indicesImpressoes = malloc(qtdImpressoes * sizeof(int));
	for(int i = 0; i < qtdImpressoes; i++) {
		scanf("%d", &indicesImpressoes[i]);
		fgetc(stdin);
		printf("%d", primos[indicesImpressoes[i]]);
		if(i != qtdImpressoes - 1)
			printf(" ");
	}

	free(primos);
	free(indicesImpressoes);

	return 0;
}