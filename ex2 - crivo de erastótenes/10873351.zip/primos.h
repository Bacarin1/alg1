
#define maiorVetor 10000 //a maior posição de vetor possível
#define maiorPrimo 104729 //o primo[maior posição de vetor possível]

int *gerarPrimos();