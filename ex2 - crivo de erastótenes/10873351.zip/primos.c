#include<stdio.h>
#include<stdlib.h>
#include"primos.h"

void preencherVetorInteiro(int *vetor) {
	for(int i = 0; i <= maiorPrimo; i++) {
		vetor[i] = i;
	}
}

void excluirNaoPrimos(int *vetor) {
	int i = 2;
	while(i*i <= maiorPrimo) {
		if(vetor[i] != 0) {
			for(int j = 2; j <= maiorPrimo; j++) {
				if(vetor[i] * j > maiorPrimo) {
					break;
				}
				else {
					vetor[vetor[i] * j] = 0;
				}
			}
		}
		i++;
	}
}

void preencherVetorPrimos(int *vetorOriginal, int *novoVetor) {
	int indexNovoVetor = 0;
	for(int i = 0; i < maiorPrimo; i++) {
		if(vetorOriginal[i] != 0) {
			novoVetor[indexNovoVetor] = vetorOriginal[i];
			indexNovoVetor++;
		}
	}
}


int *gerarPrimos() {
	int *primoscom0 = malloc(maiorPrimo * sizeof(int));

	preencherVetorInteiro(primoscom0);
	excluirNaoPrimos(primoscom0);
	int *primos = malloc(maiorVetor * sizeof(int));
	preencherVetorPrimos(primoscom0, primos);

	free(primoscom0);

	return primos;
}