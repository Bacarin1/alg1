#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define maxTexto 101
#define maxFrag 21

int lerEntrada(char *vetorEntrada, int *tamEntrada);
void substituirErro(char *ponteiro, char *texto, int *tamTexto, int *tamErro, char *correcao, int *tamCorrecao);
void limpar(char *texto, int *tamTexto, char *erro, int *tamErro, char *correcao, int *tamCorrecao);