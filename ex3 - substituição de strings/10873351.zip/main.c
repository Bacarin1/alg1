/*
* Nome: Gabriel Bacarin #10873351
* Exercício 3 - Substituição de Strings
*/
#include"subs.h"

int main() {
	char texto[maxTexto];
	int tamTexto = 0;
	char erro[maxFrag];
	int tamErro = 0;
	char correcao[maxFrag];
	int tamCorrecao = 0;

	char *ponteiro;
	int entrada;

	do {		
		do { // primeiro, lê o texto
			entrada = lerEntrada(texto, &tamTexto);
		} while(entrada != -1 && entrada != 0);

		do { // depois lê o erro
			entrada = lerEntrada(erro, &tamErro);
		} while(entrada != -1 && entrada != 0);

		do { // e lê a correção
			entrada = lerEntrada(correcao, &tamCorrecao);
		} while(entrada != -1 && entrada != 0);

		do { // vai procurar ocorrências do erro e substituir elas até que não existam mais
			ponteiro = strstr(texto, erro);

			if(ponteiro != NULL) {
				substituirErro(ponteiro, texto, &tamTexto, &tamErro, correcao, &tamCorrecao);
			}

		} while(ponteiro != NULL);

		printf("%s\n", texto);

		limpar(texto, &tamTexto, erro, &tamErro, correcao, &tamCorrecao);

	} while(entrada != 0);

	return 0;
}