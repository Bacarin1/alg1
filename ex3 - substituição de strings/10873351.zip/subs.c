#include"subs.h"

int lerEntrada(char *vetorEntrada, int *tamEntrada) {
			char entrada;

			entrada = fgetc(stdin);
			if(entrada == EOF) {
				return 0;
			}
			if(entrada != '\n') {
				*tamEntrada = *tamEntrada + 1;
				vetorEntrada[*tamEntrada - 1] = entrada;
				vetorEntrada[*tamEntrada] = '\0';
				return 1;
			}
			else {
				return -1;
			}
}

void substituirErro(char *ponteiro, char *texto, int *tamTexto, int *tamErro, char *correcao, int *tamCorrecao) {
	char restante[maxTexto];
	strcpy(restante, (ponteiro + *tamErro));
	int tamRestante = strlen(restante);

	strncpy(ponteiro, correcao, (*tamCorrecao + tamRestante));
	strcat(texto, restante);

	*tamTexto = strlen(texto);
}

void limparVetor(char *vetor, int maxVetor) {
	for(int i = 0; i < maxVetor; i++) {
		vetor[i] = '\0';
	}
}

void limpar(char *texto, int *tamTexto, char *erro, int *tamErro, char *correcao, int *tamCorrecao) {
	limparVetor(texto, maxTexto);
	limparVetor(erro, maxFrag);
	limparVetor(correcao, maxFrag);

	*tamTexto = 0;
	*tamErro = 0;
	*tamCorrecao = 0;
}