/*
	Nome: Gabriel Bacarin #10873351
	Alg 1 - Projeto 2 - Árvores Treaps
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"treap.h"

int main() {
	int qtdOp;
	scanf("%d ", &qtdOp);

	treap *arvore = criar(); //criando a árvore que será usada

	for(int i = 0; i < qtdOp; i++) { //pela quantidade de ops
		char comando[10];
		int qtdComando = 0;

		while(1) { // lendo o comando
			char entrada = fgetc(stdin);
			if(entrada == '\r')
				continue;
			if(entrada != ' ') {
				comando[qtdComando] = entrada;
				qtdComando++;
			}
			else {
				comando[qtdComando] = '\0';
				qtdComando = 0;
				break;
			}
		}

		if(strcmp(comando, "insercao") == 0) {
			int key, prio;
			scanf("%d %d", &key, &prio);
			fgetc(stdin);
			fgetc(stdin);
			no *noTemp = buscarKey(arvore->raiz, key);
			if(noTemp != NULL) {
				printf("Elemento ja existente\n");
			}
			else {
				arvore->raiz = inserir(arvore->raiz, key, prio);
			}			
		}
		else if(strcmp(comando, "impressao") == 0) {
			char tipo[10];
			int tamTipo = 0;

			while(1) { //lendo o tipo de impressão que será feita
				char entrada = fgetc(stdin);
				if(entrada == '\r')
					continue;
				if(entrada != '\n' && entrada != EOF) {
					tipo[tamTipo] = entrada;
					tamTipo++;
				}
				else {
					tipo[tamTipo] = '\0';
					tamTipo = 0;
					break;
				}
			}

			if(strcmp(tipo, "preordem") == 0) {
				//printf("imprimindo pre ordem\n");
				preOrdem(arvore->raiz);
				printf("\n");
			}
			else if(strcmp(tipo, "ordem") == 0) {
				//printf("imprimindo em ordem\n");
				emOrdem(arvore->raiz);
				printf("\n");
			}
			else if(strcmp(tipo, "largura") == 0) {
				//printf("imprimindo em largura\n");
				largura(arvore->raiz);
				printf("\n");
			}
			else {
				//printf("imprimindo posordem\n");
				posOrdem(arvore->raiz);
				printf("\n");
			}
		}
		else if(strcmp(comando, "remocao") == 0){
			int key;
			scanf("%d", &key);
			fgetc(stdin);
			fgetc(stdin);
			no *noTemp = buscarKey(arvore->raiz, key);
			if(noTemp == NULL) {
				printf("Chave nao localizada\n");
			}
			else {
				arvore->raiz = deletarNo(arvore->raiz, key);
			}
		}
		else { //operação de busca
			int key;
			scanf("%d", &key);
			fgetc(stdin);
			fgetc(stdin);
			no *noTemp = buscarKey(arvore->raiz, key);
			if(noTemp == NULL) {
				printf("0\n");
			}
			else {
				printf("1\n");
			}
		}
	}

	//liberando memória
	liberarNos(arvore->raiz);
	free(arvore);
	return 0;
}