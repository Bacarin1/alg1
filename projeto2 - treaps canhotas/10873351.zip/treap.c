#include<stdio.h>
#include<stdlib.h>
#include"treap.h"

//função para criar uma nova treap
treap *criar() {
	treap *arvore = malloc(sizeof(treap));
	arvore->raiz = NULL;

	return arvore;
}

//encerra a treap
void liberarNos(no *raiz) {
	if(raiz != NULL) {
		liberarNos(raiz->esq);
		liberarNos(raiz->dir);
		free(raiz);
	}
}

//cria e preenche um novo nó para a treap e retorna ele
no *novoNo(int key, int prio) {
	no *novoNo = malloc(sizeof(no));
	novoNo->key = key;
	novoNo->prio = prio;
	novoNo->esq = NULL;
	novoNo->dir = NULL;

	return novoNo;
}

//procura por um nó pela sua key e retorna ele caso encontre
//caso contrário retorna NULL
no *buscarKey(no *raiz, int key) {
	if(raiz == NULL)
		return NULL;
	else if(raiz->key == key)
		return raiz;
	else if(raiz->key < key)
		return buscarKey(raiz->dir, key);
	else
		return buscarKey(raiz->esq, key);
}

//algoritmo que rotaciona um pedaço da árvore para a esquerda
no *rotacionarEsquerda(no *ini) {
	no *novaRaiz = ini->dir;
	no *ramo = novaRaiz->esq;

	novaRaiz->esq = ini;
	ini->dir = ramo;

	return novaRaiz;
}

//rotação para a direita, usada só na inserção
no *rotacionarDireita(no *ini) {
	no *novaRaiz = ini->esq;
	no * ramo = novaRaiz->dir;

	novaRaiz->dir = ini;
	ini->esq = ramo;

	return novaRaiz;
}

//função que cria um novo nó para a árvore e insere ele
//no lugar certo respeitando primeiro a lógica de ABB
//e depois a lógica de max heap
no *inserir(no *raiz, int key, int prio) {
	if(raiz == NULL)
		return novoNo(key, prio);

	if(key < raiz->key) {
		raiz->esq = inserir(raiz->esq, key, prio);
		if(raiz->esq->prio > raiz->prio) {
			raiz = rotacionarDireita(raiz);
		}
	}
	else {
		raiz->dir = inserir(raiz->dir, key, prio);
		if(raiz->dir->prio > raiz->prio) {
			raiz = rotacionarEsquerda(raiz);
		}
	}

	return raiz;
}

void preOrdem(no *raiz) {
	if(raiz != NULL) {
		printf("(%d, %d) ", raiz->key, raiz->prio);
		preOrdem(raiz->esq);
		preOrdem(raiz->dir);
	}
}

void emOrdem(no *raiz) {
	if(raiz != NULL) {
		emOrdem(raiz->esq);
		printf("(%d, %d) ", raiz->key, raiz->prio);
		emOrdem(raiz->dir);
	}
}

void posOrdem(no *raiz) {
	if(raiz != NULL) {
		posOrdem(raiz->esq);				
		posOrdem(raiz->dir);
		printf("(%d, %d) ", raiz->key, raiz->prio);
	}
}

//remoção de um nó da árvore
no *deletarNo(no *raiz, int key) {
	if(raiz == NULL)
		return NULL;

	if(key < raiz->key) {
		raiz->esq = deletarNo(raiz->esq, key);
	}
	else if(key > raiz->key) {
		raiz->dir = deletarNo(raiz->dir, key);
	}
	else if(raiz->esq == NULL) { // caso seja um nó sem um dos filhos já podemos remove-lo
		no *temp = raiz->dir;
		free(raiz);
		raiz = temp;
	}
	else if(raiz->dir == NULL) {
		no *temp = raiz->esq;
		free(raiz);
		raiz = temp;
	}
	else { // caso não seja uma folha ou semifolha, vai rotacionar esse pedaço da árvore até que se torne semifolha ou folha
		raiz = rotacionarEsquerda(raiz);
		raiz->esq = deletarNo(raiz->esq, key);
	}

	return raiz; // retorna a nova raíz após as operações
}

//função recursiva que percorre a árvore para achar a maior altura possível dela
int altura(no *raiz) {
	if(raiz == NULL)
		return 0;
	else {
		int hEsq = altura(raiz->esq);
		int hDir = altura(raiz->dir);

		if(hEsq > hDir)
			return (hEsq + 1);
		else
			return (hDir + 1);
	}
}

// função recursiva que isola nós de cada nível e imprime eles na ordem da esquerda para a direta
void imprimirNivel(no *raiz, int nivel) {
	if(raiz == NULL)
		return;
	else if(nivel == 1) {
		printf("(%d, %d) ", raiz->key, raiz->prio);
	}
	else if(nivel > 1) {
		imprimirNivel(raiz->esq, (nivel - 1));
		imprimirNivel(raiz->dir, (nivel - 1));
	}
}

//obtem a altura da árvore e chama a impressão para cada nível
void largura(no *raiz) {
	int h = altura(raiz);
	for(int i = 1; i <= h; i++) {
		imprimirNivel(raiz, i);
	}
}