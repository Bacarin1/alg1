typedef struct node no;

struct node {
	int key;
	int prio;
	no *esq, *dir;
};

typedef struct treap {
	no *raiz;
} treap;


treap *criar();
no *novoNo(int key, int prio);
no *buscarKey(no *raiz, int key);
no *rotacionarEsquerda(no *ini);
no *rotacionarDireita(no *ini);
no *inserir(no *raiz, int key, int prio);
void preOrdem(no *raiz);
void emOrdem(no *raiz);
void posOrdem(no *raiz);
no *deletarNo(no *raiz, int key);
void largura(no *raiz);
void liberarNos(no *raiz);