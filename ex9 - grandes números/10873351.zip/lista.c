#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lista.h"


number *newNumber() {
	number *new = malloc(sizeof(number));
	new->begin = NULL;
	new->end = NULL;
	new->isNeg = 0;
	new->len = 0;

	return new;
}

void negSign(number *nbr) {
	nbr->isNeg = 1;
}

void insertDigit(number *nbr, int dig) {
	no_t *newDig = malloc(sizeof(no_t));
	newDig->digit = dig;

	if(nbr->begin == NULL) {
		newDig->prev = NULL;
		nbr->begin = newDig;
	} else {
		nbr->end->next = newDig;
		newDig->prev = nbr->end;
	}
	newDig->next = NULL;
	nbr->end = newDig;

	nbr->len = nbr->len + 1;
}

void freeNumber(number *nbr) {
	no_t *aux;
	aux = nbr->begin;

	do {
		nbr->begin = nbr->begin->next;
		free(aux);
		aux = nbr->begin;
	} while(aux != NULL);
}

void printNumber(number *nbr) {
	no_t *node = nbr->begin;

	if(nbr->isNeg == 1)
		printf("-");
	while(node != NULL) {
		printf("%d", node->digit);
		node = node->next;
	}
	printf("\n");
}

void inserirAoContrario(number *nbr, int dig) {
	no_t *newDig = malloc(sizeof(no_t));
	newDig->digit = dig;

	if(nbr->end == NULL) {
		newDig->next = NULL;
		nbr->end = newDig;
	} else {
		nbr->begin->prev = newDig;
		newDig->next = nbr->begin;
	}
	newDig->prev = NULL;
	nbr->begin = newDig;

	nbr->len = nbr->len + 1;
}

number *soma(number *n1, number *n2) {
	number *sum = newNumber();
	int maxLen;
	if(n1->len >= n2->len)
		maxLen = n1->len;
	else
		maxLen = n2->len;

	no_t *percorre1 = n1->end;
	no_t *percorre2 = n2->end;

	int carry = 0;

	for(int i = 0; i < maxLen; i++) {
		int soma = 0;
		if(percorre1 != NULL) {
			soma += percorre1->digit;
			percorre1 = percorre1->prev;
		}
		if(percorre2 != NULL) {
			soma += percorre2->digit;
			percorre2 = percorre2->prev;
		}
		soma += carry;

		carry = (int)(soma / 10);
		soma = soma % 10;

		inserirAoContrario(sum, soma);
	}
	if(carry != 0)
		inserirAoContrario(sum, carry);

	return sum;
}

int maiorQue(number *n1, number *n2) {
	if(n1->len != n2->len) { //qtd diferente de algarismos
		if(n1->isNeg == 0 && n2->isNeg == 0) {
			if(n1->len > n2->len)
				return 1;
			else
				return 0;
		}
		else if(n1->isNeg == 1 && n2->isNeg == 0) {
			return 0;
		}
		else if(n1->isNeg == 0 && n2->isNeg == 1) {
			return 1;
		}
		else {
			if(n1->len > n2->len)
				return 0;
			else
				return 1;
		}
	}
	else { //mesma qtd de algarismos
		if(n1->isNeg != n2->isNeg) { // caso apenas um seja negativo
			if(n1->isNeg == 1)
				return 0;
			else
				return 1;
		}

		//aqui os dois são ou positivos ou negativos
		no_t *percorre1 = n1->begin;
		no_t *percorre2 = n2->begin;
		while(percorre1 != NULL) {
			if(percorre1->digit > percorre2->digit) {
				if(n1->isNeg == 0)
					return 1;
				else
					return 0;
			}
			else if(percorre1->digit < percorre2->digit)
				if(n2->isNeg == 0)
					return 0;
				else
					return 1;
			else {
				percorre1 = percorre1->next;
				percorre2 = percorre2->next;
			}
		}
		return 0;
	}
}

int menorQue(number *n1, number *n2) {
	if(n1->len != n2->len) {
		if(n1->isNeg == 0 && n2->isNeg == 0) {
			if(n1->len > n2->len)
				return 0;
			else
				return 1;
		}
		else if(n1->isNeg == 1 && n2->isNeg == 0) {
			return 1;
		}
		else if(n1->isNeg == 0 && n2->isNeg == 1) {
			return 0;
		}
		else {
			if(n1->len > n2->len)
				return 1;
			else
				return 0;
		}
	}
	else {
		if(n1->isNeg != n2->isNeg) {
			if(n1->isNeg == 1)
				return 1;
			else
				return 0;
		}
		no_t *percorre1 = n1->begin;
		no_t *percorre2 = n2->begin;
		while(percorre1 != NULL) {
			if(percorre1->digit > percorre2->digit) {
				if(n1->isNeg == 0)
					return 0;
				else
					return 1;
			}
			else if(percorre1->digit < percorre2->digit) {
				if(n1->isNeg == 0)
					return 1;
				else
					return 0;
			}
			else {
				percorre1 = percorre1->next;
				percorre2 = percorre2->next;
			}
		}
		return 0;
	}
}

int igual(number *n1, number *n2) {
	if(n1->isNeg != n2->isNeg) {
		return 0;
	}
	if(n1->len != n2->len) {
		return 0;
	}
	no_t *percorre1 = n1->begin;
	no_t *percorre2 = n2->begin;

	int maxLen = n1->len;

	for(int i = 0; i < maxLen; i++) {
		if(percorre1 != NULL && percorre2 != NULL) {
			if(percorre1->digit != percorre2->digit) {
				return 0;
			}
			percorre1 = percorre1->next;
			percorre2 = percorre2->next;
		}
		else {
			return 1;
		}
	}
	return 1;
}

/*struct node {
	int digit;
	no_t *prev, *next;
};

typedef struct number {
	int isNeg;
	int len;
	no_t *begin, *end;
} number;*/