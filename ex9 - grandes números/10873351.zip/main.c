#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lista.h"

void readNumber(number *n) {
	char input;
	int digit;
	int zeroEsq = 0;

	while(1) {
		input = fgetc(stdin);
		if(input == '\r') {
			continue;
		}
		if(input == '-') {
			negSign(n);
		}
		else if(input == ' ' || input == '\n') {
			break;
		}
		else {
			digit = atoi(&input);
			if(digit != 0) {
				insertDigit(n, digit);
				zeroEsq = 1;
			}
			else { // entrada é 0
				if(zeroEsq != 0) // o zero não é a esquerda
					insertDigit(n, digit);
			}			
		}
	}
}

int main() {
	int n;
	scanf("%d ", &n);

	char comando[10];
	char entrada;
	int tam = 0;

	for(int i = 0; i < n; i++) {
		number *n1 = newNumber();
		number *n2 = newNumber();

		while(1) {
			entrada = fgetc(stdin);
			if(entrada == ' ') {
				comando[tam] = '\0';
				tam = 0;
				break;
			}
			comando[tam] = entrada;
			tam++;
		}

		readNumber(n1);
		readNumber(n2);

		if(strcmp(comando, "SUM") == 0) {
			number *sum = soma(n1, n2);
			printNumber(sum);
			freeNumber(sum);
		}
		else if(strcmp(comando, "BIG") == 0) {
			int resp = maiorQue(n1, n2);
			printf("%d\n", resp);
		}
		else if(strcmp(comando, "SML") == 0) {
			int resp = menorQue(n1, n2);
			printf("%d\n", resp);
		}
		else if(strcmp(comando, "EQL") == 0) {
			int resp = igual(n1, n2);
			printf("%d\n", resp);
		}

		freeNumber(n1);
		freeNumber(n2);
	}

	return 0;
}