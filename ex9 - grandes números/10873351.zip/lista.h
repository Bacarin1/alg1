typedef struct node no_t;

struct node {
	int digit;
	no_t *prev, *next;
};

typedef struct number {
	int isNeg;
	int len;
	no_t *begin, *end;
} number;

number *newNumber();
void negSign(number *nbr);
void insertDigit(number *nbr, int dig);
void freeNumber(number *nbr);
void printNumber(number *nbr);
void inserirAoContrario(number *nbr, int dig);
number *soma(number *n1, number *n2);
int maiorQue(number *n1, number *n2);
int menorQue(number *n1, number *n2);
int igual(number *n1, number *n2);
