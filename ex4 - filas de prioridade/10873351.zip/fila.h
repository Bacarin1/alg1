/*FILA
First in - first out
Novos elementos entram no fim da fila; elementos são retirados do
início da fila
operações: entrar na fila, sair da fila, contar quantos elementos,
		   reset na fila, isFull, isEmpty, ...

alocação sequencial: os elementos ficam em sequência na
memória
alocação estática: todo o espaço é alocado em tempo de compilação e
permanece reservado independente de estar sendo usado ou não

implementação: variável de início, variável de fim e total de
elementos

para reutilizar posições liberadas, usamos a fila em vetor circular

condição para fila vazia - total = 0
condição para fila cheia - total = tam
condição inicial - inicio = fim = total = 0
*/

#define tamFila 100

typedef struct pessoa {
	char nome[20];
	short int idade;
	short int condicao;
} elem;

typedef struct fila fila_t;

fila_t *criar();
int isEmpty(fila_t *f);
int isFull(fila_t *f);
int inserir(fila_t *f, elem x);
int remover(fila_t *f, elem *x);
void destruir(fila_t *f);