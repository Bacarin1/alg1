/*
	Nome: Gabriel Bacarin
	N: 10873351
	SCC 0202 - Exercício 4 - Filas de Prioridade
*/

#include<stdio.h>
#include<stdlib.h>
#include"fila.h"
#include<string.h>


elem chamarProximo(fila_t *f0, fila_t *f1, fila_t *f2, fila_t *f3) {
	elem pessoa;

	if(isEmpty(f0) != 1) {
		remover(f0, &pessoa);
	}
	else if(isEmpty(f1) != 1) {
		remover(f1, &pessoa);
	}
	else if(isEmpty(f2) != 1) {
		remover(f2, &pessoa);
	}
	else if(isEmpty(f3) != 1) {
		remover(f3, &pessoa);
	}
	else {
		pessoa.idade = -1;
	}

	return pessoa;
}

void entrarFila(elem *pessoa, fila_t *f0, fila_t *f1, fila_t *f2, fila_t *f3) {
	if(pessoa->condicao == 1) {
		if(pessoa->idade >= 60) {
			if(!isFull(f0)) {
				inserir(f0, *pessoa);
				return;
			}
		}
		else {
			if(!isFull(f1)) {
				inserir(f1, *pessoa);
				return;
			}
		}
	}
	else {
		if(pessoa->idade >= 60) {
			if(!isFull(f2)) {
				inserir(f2, *pessoa);
				return;
			}
		}
		else {
			if(!isFull(f3)) {
				inserir(f3, *pessoa);
				return;
			}
		}
	}
	printf("FILA CHEIA\n");
}


int main() {

	fila_t *f0 = criar(); // idosos com condições de saúde
	fila_t *f1 = criar(); // não idosos com condições de saúde
	fila_t *f2 = criar(); // idosos sem condições de saúde
	fila_t *f3 = criar(); // não idosos sem condições de saúde

	int qtdOperacoes = 0;
	scanf("%d", &qtdOperacoes);
	int i = 0;
	int j = qtdOperacoes;

	fgetc(stdin);
	char op[8];

	while(i < j) {		
		elem pessoa;

		scanf("%s", op);
		fgetc(stdin);

		if(strcmp(op, "SAI") == 0) {
			pessoa = chamarProximo(f0, f1, f2, f3);
			if(pessoa.idade == -1) {
				printf("FILA VAZIA\n");
			}
			else {
				printf("%s %hd %hd\n", pessoa.nome, pessoa.idade, pessoa.condicao);
			}
		}
		else {
			scanf("%s %hd %hd", pessoa.nome, &pessoa.idade, &pessoa.condicao);
			fgetc(stdin);
			entrarFila(&pessoa, f0, f1, f2, f3);
		}
		i++;
	} 

	destruir(f0);
	destruir(f1);
	destruir(f2);
	destruir(f3);

	return 0;
}